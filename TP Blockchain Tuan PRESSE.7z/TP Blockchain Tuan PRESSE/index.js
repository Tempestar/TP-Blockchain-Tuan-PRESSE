const Block = require("./Block");
const Blockchain = require("./Blockchain");

let b3chain = new Blockchain();
b3chain.addNewBlock(new Block(1, Date.now(), {sender: 'Bob', recipient: 'Alice', qty: 2}));
b3chain.addNewBlock(new Block(2, Date.now(), {sender: 'Alice', recipient: 'Bob', qty: 4}));

console.log(JSON.stringify(b3chain, null, 4));

checkChainValidity(chain); {
    for (let i = 1; i < chain.length; i++) {
        const currentBlock = chain[i];
        const precedingBlock = chain[i - 1];

        if (currentBlock.hash !== currentBlock.computeHash()) return false;
        if (currentBlock.precedingHash !== precedingBlock.hash) return false;
    }
    return true;
}

const express = require('express')
const Blockchain = require('./Blockchain')
const Block = require('./Block')

const PORT = process.env.PORT || 3001

const app = express()
app.use(express.json())

const blockchain = new Blockchain()

app.get('/blocks', (req,res) => {
    res.json(blockchain.chain)
})

app.post('/mine', (req,res) => {
    blockchain.addNewBlock(new Block(req.body))
    res.redirect('/blocks')
})

app.listen(PORT, () => {
    console.log('listening on port', PORT)
})

const Block = require('./Block')

const socketListener = (socket, chain) => {
    socket.on('mine', (data) => {
        console.info(data)
    })
    return socket
}

module.exports = socketListener

app.post('/nodes', (req,res) => {
    const {host, port} = req.body
    const {callback} = req.query
    const node = `http://${host}:${port}`
    const socketNode = socketListener(client(node), blockchain)
    blockchain.addNewNode(socketNode)

    if(callback ==='true'){
        console.info(`Node ${node} added via callback`)
        res.json({status: 'Added node', node: node, callback: true})
    }else{
        fetch(`${node}/nodes?callback=true`, {
            method: 'POST',
            headers: {
                'Accept':'application/json',
                'Content-Type':'application/json'
            },
            body: JSON.stringify({host: req.hostname, port: PORT})
        })
        console.info(`Node ${node} added via callback`)
        res.json({status: 'Added node', node: node, callback: false})
    }
})

app.get('/nodes', (req,res) => {
    res.json({count: blockchain.nodes.length})
    console.log(blockchain.nodes)
})

io.on('connection', (socket) => {
    console.info(`Socket connected ${socket.id}`)
    socket.on('disconnect', () => {
        console.info(`Socket disconnected ${socket.id}`)
    })
})

blockchain.addNewNode(socketListener(client(`http://localhost:${PORT}`), blockchain))

app.post('/mine', (req,res) => {
    const {sender, receiver, qty} = req.body
    io.emit('mine', sender, receiver, qty)
    res.redirect('/blocks')
})

const socketListener = (socket, chain) => {
    socket.on('mine', (sender, receiver, qty) => {
        let block = new Block({sender, receiver, qty})
        chain.addNewBlock(block)
        console.info(`Block number ${block.index} just mined`)
    })
    return socket
}
