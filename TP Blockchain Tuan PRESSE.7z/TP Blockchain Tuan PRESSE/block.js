const sha256 = require('crypto-js/sha256')

class Block {
    constructor(index, timestamp, data, precedinghash = ""){
        this.index = index
        this.timestamp = timestamp
        this.data = data
        this.precedingHash = precedinghash
        this.hash = this.computeHash()
    }

    computeHash(){
        return sha256(this.index + this.timestamp + JSON.stringify(this.data) + this.precedingHash).toString()
    }
}

module.exports = Block

const Block = require('./Block')

class Blockchain{
    constructor(){
        this.blockchain = [this.startGenesisBlock()]
    }
    startGenesisBlock(){
        return new Block(0, Date.now(), {sender: '', recipient: '', qty: 0}, "0")
    }
    getLatestBlock(){
        return this.blockchain[this.blockchain.length - 1]
    }
    addNewBlock(newblock){
        newblock.precedingHash = this.getLatestBlock().hash
        newblock.hash = newblock.computeHash()
        this.blockchain.push(newblock)
    }

    addNewNode(node){
        this.nodes.push(node)
    }
}

module.exports = Blockchain